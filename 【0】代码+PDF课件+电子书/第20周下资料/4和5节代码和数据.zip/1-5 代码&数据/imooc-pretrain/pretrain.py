#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : 2025/02/14 11:29
@Author  : thezehui@gmail.com
@File    : pretrain.py
"""
import datasets
import modelscope
import transformers


def main():
    # 1.从json文件中加载数据集
    raw_datasets = datasets.load_dataset(
        "json", data_files="./data/wikipedia-zh-cn-20241020.json"
    )

    # 2.将数据集划分为训练数集和测试集，测试集占10%
    raw_datasets = raw_datasets["train"].train_test_split(test_size=0.1, seed=1234)
    print("dataset info")
    print(raw_datasets)

    # 3.加载分词器，使用模搭社区将模型的配置文件和Tokenizer下载到本地
    modelscope.AutoConfig.from_pretrained("Qwen/Qwen2-0.5B").save_pretrained(
        "Qwen2-0.5B"
    )
    modelscope.AutoTokenizer.from_pretrained("Qwen/Qwen2-0.5B").save_pretrained(
        "Qwen2-0.5B"
    )

    # 4.设置上下文长度为512
    context_length = 512  # 设置上下文长度为512

    # 5.从本地加载Qwen2-0.5B分词器
    tokenizer = transformers.AutoTokenizer.from_pretrained(
        "./Qwen2-0.5B"
    )

    # 6.定义预处理数据集处理器
    def tokenize(element):
        # 6.1 对传递的文本进行分词处理
        outputs = tokenizer(
            element["text"],
            truncation=True,
            max_length=context_length,
            return_overflowing_tokens=True,
            return_length=True,
        )
        input_batch = []

        # 6.2 遍历分词结果，筛选出长度等于context_length的文本，如果需要将小于context_length长度的文本可以使用填充
        for length, input_ids in zip(outputs["length"], outputs["input_ids"]):
            if length == context_length:
                input_batch.append(input_ids)
        return {"input_ids": input_batch}

    # 7.对数据集应用tokenize函数，执行批处理，并移除原始列名
    tokenized_datasets = raw_datasets.map(
        tokenize, batched=True, remove_columns=raw_datasets["train"].column_names, num_proc=8,
    )
    print("tokenize dataset info")
    print(tokenized_datasets)

    # 8.设置预填token为结束token
    tokenizer.pad_token = tokenizer.eos_token

    # 9.创建数据收集器，用于语言模型训练，mlm为False表示不使用掩码语言模型
    data_collator = transformers.DataCollatorForLanguageModeling(tokenizer, mlm=False)

    # 10.预设模型的配置信息
    config = transformers.AutoConfig.from_pretrained(
        "./Qwen2-0.5B",
        vocab_size=len(tokenizer),
        hidden_size=512,
        intermediate_size=2048,
        num_attention_heads=8,
        num_hidden_layers=12,
        n_ctx=context_length,
        bos_token_id=tokenizer.bos_token_id,
        eos_token_id=tokenizer.eos_token_id,
    )

    # 11.创建Qwen2模型
    model = transformers.Qwen2ForCausalLM(config).to("cuda")

    # 12.计算模型参数信息
    model_size = sum(t.numel() for t in model.parameters())
    print("模型配置:")
    print(config)
    print(f"模型大小: {model_size / 1000 ** 2:.1f}M parameters")

    # 13.设置预训练参数
    args = transformers.TrainingArguments(
        output_dir="ImoocLLM",  # 输出目录
        per_device_train_batch_size=4,  # 每个GPU的训练batch数
        per_device_eval_batch_size=4,  # 每个GPU的测试batch数
        dataloader_num_workers=4,  # 新增数据加载工作进程
        dataloader_prefetch_factor=2,  # 预取数据量
        eval_strategy="steps",  # 评估策略为依据部署
        eval_steps=5_00,  # 每500步评估一次
        logging_steps=50,  # 每50步记录一次日志
        gradient_accumulation_steps=32,  # 梯度累计总数，原来是8升为32
        gradient_checkpointing=True,  # 新增，用计算时间换显存
        num_train_epochs=2,  # 训练轮数
        weight_decay=0.1,  # 权重衰减
        warmup_steps=2_00,  # 预热部署
        optim="adamw_torch",  # 优化器
        lr_scheduler_type="cosine",  # 学习率衰减策略
        learning_rate=5e-4,  # 基础学习率，
        save_steps=5_00,  # 每500步保存一次
        save_total_limit=10,  # 最大保存次数
        no_cuda=False,  # 启用cuda加速
        fp16=True,  # 优先使用fp16（NVIDIA显卡兼容性更好）
    )
    print("训练参数:")
    print(args)

    # 14.创建训练器
    trainer = transformers.Trainer(
        model=model,
        tokenizer=tokenizer,
        args=args,
        data_collator=data_collator,
        train_dataset=tokenized_datasets["train"],
        eval_dataset=tokenized_datasets["test"],
    )
    trainer.train()

    # 15.保存模型
    model.save_pretrained("./ImoocLLM/Weight")  # 保存模型的路径

    # 16.生成文本
    pipe = transformers.pipeline("text-generation", model=model, tokenizer=tokenizer)
    print("GENERATE:", pipe("人工智能", num_return_sequences=1)[0]["generated_text"])
    prompts = ["慕课网", "Agent智能体", "马拉松"]
    examples = []
    for i in range(3):
        # 17.根据提示词生成数据
        text = pipe(prompts[i], num_return_sequences=1)[0]["generated_text"]
        examples.append(text)
    print({"generate": examples})


if __name__ == "__main__":
    main()
