#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Qwen2.5-0.5B-Instruct 微调脚本

@Time    : 2025/02/16 0:33
@Author  : thezehui@gmail.com
@File    : fine_tuning.py
"""

import json
import os

import pandas as pd
import torch
from datasets import Dataset
from modelscope import snapshot_download
from peft import LoraConfig, TaskType, get_peft_model
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
)

# 全局配置参数
CONFIG = {
    "max_length": 384,  # 输入序列最大长度
    "lora_rank": 8,  # LoRA秩
    "lora_alpha": 32,  # LoRA alpha值
    "lora_dropout": 0.1,  # LoRA dropout比例
    "batch_size": 4,  # 单设备训练批量大小
    "grad_accum_steps": 4,  # 梯度累积步数
    "learning_rate": 1e-4,  # 学习率
    "num_epochs": 5,  # 训练轮数
    "output_dir": "./output/Qwen2.5",  # 输出目录
    "model_name": "Qwen/Qwen2.5-1.5B-Instruct",  # 模型名称
    "cache_dir": "./model_cache",  # 模型缓存目录
    "train_data": "./data/train.jsonl",  # 原始训练数据路径
    "test_data": "./data/test.jsonl",  # 原始测试数据路径
}


def dataset_jsonl_transfer(origin_path: str, new_path: str) -> None:
    """
    将原始数据转换为微调所需的jsonl格式

    Args:
        origin_path: 原始数据路径
        new_path: 转换后数据保存路径

    Format:
        原始数据格式：{"query": "...", "answer": "..."}
        目标数据格式：{"instruction": "...", "input": "...", "output": "..."}
    """
    try:
        # 1.检查原始文件是否存在
        if not os.path.exists(origin_path):
            raise FileNotFoundError(f"原始数据文件 {origin_path} 不存在")

        messages = []
        with open(origin_path, "r", encoding="utf-8") as f:
            for line in f:
                data = json.loads(line)
                messages.append({
                    "instruction": "你是一个强大的聊天机器人，请回答用户的问题。",
                    "input": data["query"],
                    "output": data["answer"]
                })

        # 2.确保输出目录存在
        os.makedirs(os.path.dirname(new_path), exist_ok=True)

        # 3.写入转换后的数据
        with open(new_path, "w", encoding="utf-8") as f:
            for msg in messages:
                f.write(json.dumps(msg, ensure_ascii=False) + "\n")

    except Exception as e:
        print(f"数据转换失败: {str(e)}")
        raise


def process_func(example: dict) -> dict:
    """
    数据集预处理函数：将文本转换为模型输入格式

    处理逻辑：
    1. 拼接系统提示、用户输入和助手开头标记
    2. 对响应内容单独编码
    3. 组合输入ID和注意力掩码
    4. 设置labels（仅对响应部分计算损失）
    """
    # 1.编码系统提示和用户输入部分
    instruction = tokenizer(
        "<|im_start|>system\n你是一个强大的聊天机器人，请回答用户的问题。<|im_end|>\n"
        f"<|im_start|>user\n{example['input']}<|im_end|>\n"
        "<|im_start|>assistant\n",
        add_special_tokens=False,
    )

    # 2.编码助手响应部分
    response = tokenizer(example["output"], add_special_tokens=False)

    # 3.组合各部分
    input_ids = instruction["input_ids"] + response["input_ids"] + [tokenizer.pad_token_id]
    attention_mask = instruction["attention_mask"] + response["attention_mask"] + [1]
    labels = [-100] * len(instruction["input_ids"]) + response["input_ids"] + [tokenizer.pad_token_id]

    # 4.截断到最大长度
    if len(input_ids) > CONFIG["max_length"]:
        input_ids = input_ids[:CONFIG["max_length"]]
        attention_mask = attention_mask[:CONFIG["max_length"]]
        labels = labels[:CONFIG["max_length"]]

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels
    }


def predict(messages: list, model: AutoModelForCausalLM, tokenizer: AutoTokenizer) -> str:
    """
    生成预测结果

    Args:
        messages: 消息列表，格式[{"role": "system/user/assistant", "content": "..."}]
        model: 已加载的模型
        tokenizer: 已加载的分词器

    Returns:
        str: 模型生成的响应文本
    """
    # 1.自动检测可用设备
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)

    # 2.应用聊天模板
    text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    # 3.编码输入
    model_inputs = tokenizer(text, return_tensors="pt").to(device)

    # 4.生成响应
    generated_ids = model.generate(
        model_inputs.input_ids,
        max_new_tokens=512,
        pad_token_id=tokenizer.pad_token_id
    )

    # 5.解码输出
    response = tokenizer.decode(
        generated_ids[0][len(model_inputs.input_ids[0]):],
        skip_special_tokens=True
    )

    return response


if __name__ == "__main__":
    # 1.从ModelScope下载模型（如果缓存中不存在） --------------------------------------------------------
    model_dir = snapshot_download(
        CONFIG["model_name"],
        cache_dir=CONFIG["cache_dir"],
        revision="master"
    )

    # 2.加载分词器
    tokenizer = AutoTokenizer.from_pretrained(
        model_dir,
        use_fast=False,
        trust_remote_code=True
    )

    # 3.加载模型
    model = AutoModelForCausalLM.from_pretrained(
        model_dir,
        device_map="auto",
        torch_dtype=torch.bfloat16,
    )
    model.enable_input_require_grads()  # 开启梯度检查点必需

    # 4.定义处理后的数据路径 --------------------------------------------------------------
    train_jsonl = os.path.join(CONFIG["output_dir"], "processed_train.jsonl")
    test_jsonl = os.path.join(CONFIG["output_dir"], "processed_test.jsonl")

    # 5.转换训练数据（如果尚未处理）
    if not os.path.exists(train_jsonl):
        dataset_jsonl_transfer(CONFIG["train_data"], train_jsonl)
    if not os.path.exists(test_jsonl):
        dataset_jsonl_transfer(CONFIG["test_data"], test_jsonl)

    # 6.创建HuggingFace数据集
    train_dataset = Dataset.from_pandas(pd.read_json(train_jsonl, lines=True))
    train_dataset = train_dataset.map(process_func, remove_columns=train_dataset.column_names)

    # 7. 配置LoRA -------------------------------------------------------------
    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        target_modules=[
            "q_proj", "k_proj", "v_proj",
            "o_proj", "gate_proj",
            "up_proj", "down_proj"
        ],  # 注意：不同模型的模块名称可能不同
        inference_mode=False,
        r=CONFIG["lora_rank"],
        lora_alpha=CONFIG["lora_alpha"],
        lora_dropout=CONFIG["lora_dropout"],
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()  # 打印可训练参数占比

    # 8. 训练配置 -------------------------------------------------------------
    training_args = TrainingArguments(
        output_dir=CONFIG["output_dir"],
        per_device_train_batch_size=CONFIG["batch_size"],
        gradient_accumulation_steps=CONFIG["grad_accum_steps"],
        logging_steps=10,  # 每10步记录一次日志
        num_train_epochs=CONFIG["num_epochs"],
        save_steps=100,  # 每100步保存一次检查点
        learning_rate=CONFIG["learning_rate"],
        fp16=True,  # 启用混合精度训练
        gradient_checkpointing=True,  # 启用梯度检查点
        report_to="none",  # 禁用第三方报告
        remove_unused_columns=False,  # 保持所有列
        optim="adamw_torch",  # 使用AdamW优化器
    )

    # 9.数据收集器（自动填充到相同长度）
    data_collator = DataCollatorForSeq2Seq(
        tokenizer=tokenizer,
        padding=True,
        pad_to_multiple_of=8  # 填充到8的倍数，提升计算效率
    )

    # 10. 开始训练 -------------------------------------------------------------
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=data_collator,
    )
    trainer.train()

    # 11. 测试模型 -------------------------------------------------------------
    test_df = pd.read_json(test_jsonl, lines=True)[:10]  # 取前10条测试

    results = []
    for _, row in test_df.iterrows():
        # 12.构建模型消息格式
        messages = [
            {"role": "system", "content": row["instruction"]},
            {"role": "user", "content": row["input"]}
        ]

        # 13.获取模型响应内容
        response = predict(messages, model, tokenizer)

        # 14.保存结果
        results.append({
            "input": row["input"],
            "true_output": row["output"],
            "pred_output": response
        })

        # 15.打印结果
        print(f"\nInput: {row['input']}")
        print(f"True Output: {row['output']}")
        print(f"Predicted Output: {response}")
        print("=" * 50)

    # 16.保存测试结果到文件
    result_path = os.path.join(CONFIG["output_dir"], "test_results.json")
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"\n测试结果已保存至：{result_path}")
