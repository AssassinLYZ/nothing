#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : 2025/02/10 16:51
@Author  : thezehui@gmail.com
@File    : websocket_spark_llm_demo.py
"""
import asyncio
import base64
import hashlib
import hmac
import json
from datetime import datetime
from time import mktime
from urllib.parse import urlencode
from wsgiref.handlers import format_date_time

import websockets


async def main():
    # 1.配置讯飞大语言配置信息
    app_id = "254ae791"
    api_key = "f00412b16b43ccb65fdf086d7b19fb56"
    api_secret = "OWRlOTZmMjkxNmY0YjFiOTdhZDJjZjM3"
    wss_url = "wss://spark-api.xf-yun.com/v3.5/chat"
    domain = "generalv3.5"

    # 2.获取当前时间并格式化日期
    current_time = datetime.now()
    date = format_date_time(mktime(current_time.timetuple()))

    # 3.构建鉴权字符串
    tmp = "host: llmops.shortvar.com\n"
    tmp += "date: " + date + "\n"
    tmp += "GET /v3.5/chat HTTP/1.1"

    # 4.加密鉴权字符串
    tmp_sha = hmac.new(api_secret.encode("utf-8"), tmp.encode("utf-8"), digestmod=hashlib.sha256).digest()

    # 5.将加密字符串转base64
    signature = base64.b64encode(tmp_sha).decode(encoding="utf-8")

    # 6.生成鉴权凭证
    authorization_origin = f"api_key=\"{api_key}\", algorithm=\"hmac-sha256\", headers=\"host date request-line\", signature=\"{signature}\""
    authorization = base64.b64encode(authorization_origin.encode("utf-8")).decode(encoding="utf-8")

    # 7.组装websocket传递参数
    v = {
        "authorization": authorization,
        "date": date,
        "host": "llmops.shortvar.com"
    }

    # 8.获取用户输入
    query = input("Human: ")
    # 8.创建websocket连接
    async with websockets.connect(wss_url + "?" + urlencode(v)) as websocket:
        # 9.构建请求数据
        data = {
            "header": {"app_id": app_id},
            "parameter": {
                "chat": {
                    "domain": domain,
                    "temperature": 0.5,
                    "max_tokens": 1024
                }
            },
            "payload": {
                "message": {
                    "text": [
                        {"role": "system", "content": "你是一个强大的聊天机器人，请帮用户解决问题"},
                        {"role": "user", "content": query}
                    ]
                }
            }
        }
        await websocket.send(json.dumps(data))
        print("Ai: ", flush=True, end="")
        async for response in websocket:
            data = json.loads(response)
            print(data["payload"]["choices"]["text"][0]["content"], flush=True, end="")
        print("\n")


if __name__ == "__main__":
    asyncio.run(main())
